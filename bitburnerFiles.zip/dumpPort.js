/** @param {NS} ns */
export async function main(ns) {
	while(!(ns.readPort(ns.args[0]) == "NULL PORT DATA")){
	}
}